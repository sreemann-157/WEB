\
const express = require('express');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

// === Configuration ===
// Change this if your MongoDB is hosted elsewhere or uses auth
const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/libraryDB';

// Middleware
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// === Mongoose model ===
mongoose.connect(MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('Connected to MongoDB:', MONGO_URI))
  .catch(err => console.error('MongoDB connection error:', err));

const bookSchema = new mongoose.Schema({
  bookId: { type: Number, unique: true, required: true },
  title: String,
  author: String,
  genre: String,
  copies: Number
}, { collection: 'books' });

const Book = mongoose.model('Book', bookSchema);

// === API routes ===
// Get all books
app.get('/api/books', async (req, res) => {
  try {
    const books = await Book.find().sort({ bookId: 1 });
    res.json(books);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Add a book
app.post('/api/book', async (req, res) => {
  try {
    const data = req.body;
    const book = new Book(data);
    await book.save();
    res.json({ message: 'Book added successfully', book });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Update a book by bookId
app.put('/api/book/:bookId', async (req, res) => {
  try {
    const bookId = parseInt(req.params.bookId);
    const updated = await Book.findOneAndUpdate({ bookId }, req.body, { new: true, runValidators: true });
    if (!updated) return res.status(404).json({ error: 'Book not found' });
    res.json({ message: 'Book updated', book: updated });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Delete a book by bookId
app.delete('/api/book/:bookId', async (req, res) => {
  try {
    const bookId = parseInt(req.params.bookId);
    const removed = await Book.findOneAndDelete({ bookId });
    if (!removed) return res.status(404).json({ error: 'Book not found' });
    res.json({ message: 'Book deleted' });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Fallback: serve static files (frontend)
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'library.html'));
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/`);
});
