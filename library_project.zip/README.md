Library App - AngularJS frontend + Node.js (Express) + MongoDB (Mongoose)
=====================================================================

What you get
------------
- public/library.html      -> AngularJS single-page frontend (works like your student app but for books)
- server.js                -> Express server + Mongoose API + serves static frontend
- package.json             -> Node dependencies
- tests/selenium_test.py   -> Selenium test (Python) using webdriver-manager to run against the running app
- requirements.txt         -> Python requirements for Selenium test

Defaults / Assumptions
----------------------
- MongoDB (Compass) is expected to be running locally and accessible at:
  mongodb://127.0.0.1:27017
- Database name: libraryDB
- Collection: books
- Server port: 5000
- Static frontend is served at: http://localhost:5000/

How to run (Node / server)
--------------------------
1. Install Node.js (v14+ recommended) and npm.
2. In the project folder run:
   npm install
3. Start the server:
   node server.js
4. Open the app in a browser:
   http://localhost:5000/library.html

How to run Selenium tests (Python)
---------------------------------
1. Install Python 3 (3.8+ recommended).
2. Create and activate a virtualenv (optional):
   python -m venv venv
   source venv/bin/activate   # (Linux / macOS)
   venv\Scripts\activate    # (Windows)
3. Install requirements:
   pip install -r requirements.txt
4. Make sure server is running:
   node server.js
5. Run the Selenium test:
   python tests/selenium_test.py

Notes
-----
- The Selenium test uses webdriver-manager to automatically download the right ChromeDriver.
- If you prefer a different browser, update tests/selenium_test.py accordingly.
- If your MongoDB uses authentication or a different host/port, update the connection string in server.js.

Enjoy! If you want changes (different fields, port, or Selenium in Java/JS), tell me and I’ll update.
