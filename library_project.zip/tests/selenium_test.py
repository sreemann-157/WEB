\
# Selenium test: opens the app, adds a book, updates it, and deletes it.
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time

BASE = "http://localhost:5000/library.html"

def wait_for(driver, by, value, timeout=10):
    return WebDriverWait(driver, timeout).until(EC.presence_of_element_located((by, value)))

def main():
    options = webdriver.ChromeOptions()
    options.add_argument("--start-maximized")
    driver = webdriver.Chrome(ChromeDriverManager().install(), options=options)
    try:
        driver.get(BASE)
        time.sleep(1)

        # Fill form to add a book
        wait_for(driver, By.CSS_SELECTOR, 'input[placeholder="Book ID"]').send_keys("1001")
        driver.find_element(By.CSS_SELECTOR, 'input[placeholder="Title"]').send_keys("Selenium Guide")
        driver.find_element(By.CSS_SELECTOR, 'input[placeholder="Author"]').send_keys("Auto Tester")
        driver.find_element(By.CSS_SELECTOR, 'input[placeholder="Genre"]').send_keys("Automation")
        driver.find_element(By.CSS_SELECTOR, 'input[placeholder="Copies"]').send_keys("3")
        driver.find_element(By.CSS_SELECTOR, 'form button[type="submit"]').click()

        # Wait for alert and accept
        WebDriverWait(driver, 5).until(EC.alert_is_present())
        alert = driver.switch_to.alert
        alert.accept()
        time.sleep(1)

        # Search for the added book
        search = wait_for(driver, By.CSS_SELECTOR, 'input.search')
        search.clear()
        search.send_keys("Selenium")
        time.sleep(1)

        # Click Edit on the first row
        edit_button = wait_for(driver, By.XPATH, '//table//tbody/tr[1]//button[contains(text(),"Edit")]')
        edit_button.click()
        time.sleep(1)

        # Change copies and update
        copies_input = driver.find_element(By.CSS_SELECTOR, 'input[placeholder="Copies"]')
        copies_input.clear()
        copies_input.send_keys("5")
        driver.find_element(By.CSS_SELECTOR, 'form button[type="submit"]').click()

        # Accept update alert
        WebDriverWait(driver, 5).until(EC.alert_is_present())
        driver.switch_to.alert.accept()
        time.sleep(1)

        # Delete the book
        delete_button = wait_for(driver, By.XPATH, '//table//tbody/tr[1]//button[contains(text(),"Delete")]')
        delete_button.click()
        # Confirm JS confirm
        WebDriverWait(driver, 5).until(EC.alert_is_present())
        alert2 = driver.switch_to.alert
        alert2.accept()
        time.sleep(1)

        print("Selenium test completed successfully.")
    finally:
        driver.quit()

if __name__ == '__main__':
    main()
